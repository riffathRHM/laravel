<h1>hai i am luxshika prashath</h1>
<?php echo e($msg); ?><?php /**PATH C:\Users\E-Lab Staff\Desktop\2019csc030\2019csc030\HelloApp\resources\views/hello.blade.php ENDPATH**/ ?>